export const icons = {
    "bell.png" : require('./images/bell.png'),
    "home.png" : require('./images/home.png'),
    "plane.png" : require('./images/plane.png'),
    "educate.png" : require('./images/educate.png'),
    "react-native.png" : require('./images/react-native.png')
};